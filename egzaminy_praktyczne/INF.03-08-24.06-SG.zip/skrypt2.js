let postepWartosc = 0;
const MAX_POSTEP = 100; // Maksymalna wartość paska postępu
const WARTOSC_KROKU = 12; // Wartość, o jaką zmienia się postęp dla jednego pola

// Pobranie początkowej szerokości paska postępu w procentach z CSS
const poczatkowaSzerokosc = 4; // To jest wartość początkowa w procentach (4%)

// Funkcja aktualizująca postęp
function aktualizujPostep() {
    let wypelnionePola = 0; // Licznik wypełnionych pól

    // Sprawdzamy każde pole i liczymy, ile jest wypełnionych
    document.querySelectorAll('input[type="text"], input[type="date"], input[type="number"], input[type="tel"]').forEach(function (input) {
        if (input.value.trim() !== '') {
            wypelnionePola++;
        }
    });

    // Obliczamy nową wartość postępu, uwzględniając początkową szerokość
    postepWartosc = poczatkowaSzerokosc + (wypelnionePola * WARTOSC_KROKU);

    // Jeśli wartość przekracza 100%, ustawiamy ją na maksymalną
    if (postepWartosc > MAX_POSTEP) {
        postepWartosc = MAX_POSTEP;
    }

    // Zaokrąglamy wartość postępu w górę
    postepWartosc = Math.ceil(postepWartosc);

    // Aktualizujemy szerokość paska postępu
    document.querySelector('#postep > div').style.width = postepWartosc + '%';

    // Sprawdzamy wartość w konsoli
    console.log(postepWartosc);
}

// Dodajemy nasłuchiwanie na zdarzenie 'blur' dla każdego odpowiedniego pola
document.querySelectorAll('input[type="text"], input[type="date"], input[type="number"], input[type="tel"]').forEach(function (input) {
    input.addEventListener('blur', aktualizujPostep);
});
