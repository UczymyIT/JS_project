function aktywujZakladke(zakladkaId){
	document.getElementById("main1").style.display = 'none';
	document.getElementById("main2").style.display = 'none';
	document.getElementById("main3").style.display = 'none';
	document.getElementById(zakladkaId).style.display = 'block';
}
function klient(){
	aktywujZakladke('main1');
}
function adres(){
	aktywujZakladke('main2');
}
function kontakt(){
	aktywujZakladke('main3');
}

let postepWartosc = 0;

function aktualizujPostep() {
    // Pobieramy obliczoną szerokość z CSS (np. 4%)
    const computedStyle = getComputedStyle(document.querySelector('#postep > div'));
	//Funkcja getComputedStyle() w JavaScript służy do pobierania obliczonych (zastosowanych) stylów CSS dla elementu DOM
    let currentWidth = parseInt(computedStyle.width); // Szerokość w pikselach, zamieniona na liczbę całkowitą
    const parentWidth = document.querySelector('#postep').offsetWidth; // Szerokość kontenera (parent element)

    // Obliczamy wartość procentową bieżącej szerokości
    let currentPercentage = (currentWidth / parentWidth) * 100;
	currentPercentage = Math.ceil(currentPercentage);

    // Jeśli pierwsze wywołanie, uwzględniamy początkową szerokość (4%)
    if (postepWartosc === 0) {
        postepWartosc = currentPercentage;
    }

    // Jeśli bieżąca szerokość jest mniejsza niż 100%, zwiększamy ją
    if (postepWartosc < 100) {
        postepWartosc += 12; // Zwiększamy o 12%

        // Upewniamy się, że nie przekroczy 100%
        if (postepWartosc > 100) {
            postepWartosc = 100;
        }

        // Ustawiamy nową szerokość elementu w procentach
        document.querySelector('#postep > div').style.width = postepWartosc + '%';
    }

    console.log('Aktualna szerokość: ' + document.querySelector('#postep > div').style.width);
}


document.querySelectorAll('input[type="text"], input[type="date"], input[type="number"], input[typu="tel"]').forEach(
	function (input){input.addEventListener('blur',aktualizujPostep);});

function zatwierdz() {
    let imie = document.getElementById('imie').value;
    let nazwisko = document.getElementById('nazwisko').value;
    let data = document.getElementById('data').value;
    let ulica = document.getElementById('ulica').value;
    let numer = document.getElementById('numer').value;
    let miasto = document.getElementById('miasto').value;
    let tel = document.getElementById('tel').value;
    let rodo = document.getElementById('rodo').checked ? 'On' : 'Of';
    console.log(imie + ", " + nazwisko + ", " + data + ", " + ulica + ", " + numer + ", " + miasto + ", " + tel + ", " + rodo);
}